https://batuhanozudogru.github.io/patika-bootcamp-assignments/Week20/JavaScript4/

![Alt text](ss.JPG)